package dev.emberbound.client;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.AbstractButton;
import net.minecraft.client.gui.narration.NarrationElementOutput;
import net.minecraft.client.input.InputWithModifiers;
import net.minecraft.network.chat.Component;

/**
 * Кнопка в стиле мода. Сначала закрашивает стандартный фон кнопки, потом рисует свой.
 */
public class EmberButton extends AbstractButton {
	private final Runnable action;

	public EmberButton(int x, int y, int width, int height, Component label, Runnable action) {
		super(x, y, width, height, label);
		this.action = action;
	}

	@Override
	protected void renderContents(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		int x = this.getX();
		int y = this.getY();
		boolean hot = this.active && this.isHovered();

		int edge = !this.active ? EmberUi.DISABLED : hot ? EmberUi.EMBER : EmberUi.EMBER_DIM;
		int fill = !this.active ? 0xFF171011 : hot ? 0xFF3A2218 : 0xFF241618;
		int text = !this.active ? EmberUi.DISABLED : hot ? EmberUi.GOLD : EmberUi.TEXT;

		graphics.fill(x, y, x + this.width, y + this.height, edge);
		graphics.fill(x + 1, y + 1, x + this.width - 1, y + this.height - 1, fill);

		if (hot) {
			graphics.fill(x + 1, y + this.height - 2, x + this.width - 1, y + this.height - 1, EmberUi.EMBER_DIM);
		}

		graphics.drawCenteredString(Minecraft.getInstance().font, this.getMessage(), x + this.width / 2, y + (this.height - 8) / 2, text);
	}

	@Override
	public void onPress(InputWithModifiers input) {
		this.action.run();
	}

	@Override
	protected void updateWidgetNarration(NarrationElementOutput output) {
	}
}
