package dev.emberbound.client;

import java.text.DecimalFormat;
import java.text.NumberFormat;

import dev.emberbound.BonfireBlock;
import dev.emberbound.Emberbound;
import dev.emberbound.ModNetwork;
import dev.emberbound.SoulsLogic;
import dev.emberbound.Stat;
import dev.emberbound.Tuning;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

/**
 * Экран прокачки: очки набираются в «корзину» кнопками +/-, душы списываются только после подтверждения.
 */
public class LevelUpScreen extends Screen {
	private static final int PANEL_W = 300;
	private static final int PANEL_H = 222;
	private static final int ROWS_TOP = 66;
	private static final int ROW_H = 26;
	private static final DecimalFormat BONUS_FORMAT = new DecimalFormat("0.##");

	private final int[] pending = new int[Stat.ALL.length];
	private final EmberButton[] minus = new EmberButton[Stat.ALL.length];
	private final EmberButton[] plus = new EmberButton[Stat.ALL.length];
	private EmberButton confirmButton;
	private boolean nearBonfire;
	private int ticks;

	public LevelUpScreen() {
		super(Component.translatable("screen.emberbound.level_up"));
	}

	@Override
	protected void init() {
		int left = (this.width - PANEL_W) / 2;
		int top = (this.height - PANEL_H) / 2;

		this.nearBonfire = this.checkBonfire();

		for (int i = 0; i < Stat.ALL.length; i++) {
			final int index = i;
			int rowY = top + ROWS_TOP + i * ROW_H;

			this.minus[i] = this.addRenderableWidget(new EmberButton(left + PANEL_W - 58, rowY, 18, 18, Component.literal("-"), () -> this.change(index, -1)));
			this.plus[i] = this.addRenderableWidget(new EmberButton(left + PANEL_W - 36, rowY, 18, 18, Component.literal("+"), () -> this.change(index, 1)));
		}

		this.confirmButton = this.addRenderableWidget(new EmberButton(left + 16, top + PANEL_H - 32, 126, 20,
				Component.translatable("screen.emberbound.confirm"), this::submit));
		this.addRenderableWidget(new EmberButton(left + PANEL_W - 142, top + PANEL_H - 32, 126, 20,
				Component.translatable("screen.emberbound.cancel"), this::onClose));
	}

	@Override
	public void tick() {
		if (++this.ticks % 10 == 0) {
			this.nearBonfire = this.checkBonfire();
		}
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private boolean checkBonfire() {
		if (Tuning.LEVEL_UP_ANYWHERE) {
			return true;
		}

		return this.minecraft != null
				&& this.minecraft.level != null
				&& this.minecraft.player != null
				&& BonfireBlock.isNearLitBonfire(this.minecraft.level, this.minecraft.player.blockPosition(), Tuning.BONFIRE_REACH);
	}

	private int totalPending() {
		int total = 0;

		for (int value : this.pending) {
			total += value;
		}

		return total;
	}

	private int baseLevel() {
		return SoulsLogic.characterLevel(this.minecraft.player);
	}

	private long pendingCost() {
		return SoulsLogic.costOfPoints(this.baseLevel(), this.totalPending());
	}

	private boolean canAdd(int index) {
		LocalPlayer player = this.minecraft.player;
		long nextCost = SoulsLogic.costOfPoints(this.baseLevel(), this.totalPending() + 1);

		return this.nearBonfire
				&& SoulsLogic.statLevel(player, Stat.ALL[index]) + this.pending[index] < Tuning.MAX_STAT_LEVEL
				&& nextCost <= SoulsLogic.souls(player);
	}

	private void change(int index, int delta) {
		if (delta > 0 && !this.canAdd(index)) {
			return;
		}

		if (delta < 0 && this.pending[index] <= 0) {
			return;
		}

		this.pending[index] += delta;
	}

	private void submit() {
		if (this.totalPending() > 0) {
			ClientPlayNetworking.send(ModNetwork.LevelUpPayload.of(this.pending));
		}

		this.onClose();
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		this.renderBackground(graphics, mouseX, mouseY, delta);

		LocalPlayer player = this.minecraft.player;
		int left = (this.width - PANEL_W) / 2;
		int top = (this.height - PANEL_H) / 2;
		int centerX = left + PANEL_W / 2;

		EmberUi.panel(graphics, left, top, PANEL_W, PANEL_H);
		EmberUi.title(graphics, this.font, this.title, centerX, top + 13);
		EmberUi.divider(graphics, left + 16, left + PANEL_W - 16, top + 36);

		int held = SoulsLogic.souls(player);
		long cost = this.pendingCost();
		int level = this.baseLevel();
		int newLevel = level + this.totalPending();

		// Сводка: уровень, души, цена.
		Component levelText = this.totalPending() > 0
				? Component.translatable("screen.emberbound.level_change", level, newLevel)
				: Component.translatable("screen.emberbound.level", level);
		graphics.drawString(this.font, levelText, left + 18, top + 44, EmberUi.TEXT, true);

		Component soulsText = Component.translatable("screen.emberbound.souls", NumberFormat.getIntegerInstance().format(held));
		graphics.drawString(this.font, soulsText, centerX - this.font.width(soulsText) / 2, top + 44, EmberUi.GOLD, true);

		Component costText = Component.translatable("screen.emberbound.cost", NumberFormat.getIntegerInstance().format(cost));
		graphics.drawString(this.font, costText, left + PANEL_W - 18 - this.font.width(costText), top + 44, cost > held ? EmberUi.RED : EmberUi.MUTED, true);

		// Строки статов.
		for (int i = 0; i < Stat.ALL.length; i++) {
			this.renderRow(graphics, Stat.ALL[i], i, left, top + ROWS_TOP + i * ROW_H);
		}

		if (!this.nearBonfire) {
			graphics.drawCenteredString(this.font, Component.translatable("screen.emberbound.need_bonfire"), centerX, top + PANEL_H - 48, EmberUi.RED);
		}

		// Состояние кнопок.
		for (int i = 0; i < Stat.ALL.length; i++) {
			this.minus[i].active = this.pending[i] > 0;
			this.plus[i].active = this.canAdd(i);
		}

		this.confirmButton.active = this.totalPending() > 0 && cost <= held;

		super.render(graphics, mouseX, mouseY, delta);
	}

	private void renderRow(GuiGraphics graphics, Stat stat, int index, int left, int y) {
		int current = SoulsLogic.statLevel(this.minecraft.player, stat);
		int next = current + this.pending[index];
		Identifier icon = Emberbound.id("stat/" + stat.key);

		graphics.blitSprite(RenderPipelines.GUI_TEXTURED, icon, left + 18, y + 3, 12, 12);
		graphics.drawString(this.font, Component.translatable("stat.emberbound." + stat.key), left + 36, y + 1, EmberUi.TEXT, true);

		String bonus = BONUS_FORMAT.format(stat.bonus(next)) + (stat.percent ? "%" : "");
		graphics.drawString(this.font, Component.translatable("stat.emberbound." + stat.key + ".bonus", bonus), left + 36, y + 11, EmberUi.MUTED, true);

		// Шкала из 30 делений: текущий уровень, добавляемые очки и пустые.
		int barX = left + 126;
		int barY = y + 6;

		for (int segment = 0; segment < Tuning.MAX_STAT_LEVEL; segment++) {
			int color = segment < current ? EmberUi.EMBER : segment < next ? EmberUi.GOLD : EmberUi.BAR_EMPTY;
			graphics.fill(barX + segment * 3, barY, barX + segment * 3 + 2, barY + 6, color);
		}

		String value = this.pending[index] > 0 ? current + ">" + next : String.valueOf(current);
		graphics.drawString(this.font, value, left + PANEL_W - 64 - this.font.width(value), y + 5, this.pending[index] > 0 ? EmberUi.GOLD : EmberUi.TEXT, true);
	}
}
