package dev.emberbound.client;

import java.text.NumberFormat;

import dev.emberbound.Emberbound;
import dev.emberbound.SoulsLogic;

import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.resources.Identifier;

/** Счётчик душ в правом нижнем углу экрана. */
public final class SoulsHud {
	private SoulsHud() {
	}

	private static final Identifier SHARD_SPRITE = Emberbound.id("hud/shard");

	public static void render(GuiGraphics graphics, DeltaTracker tracker) {
		Minecraft client = Minecraft.getInstance();

		if (client.player == null || client.options.hideGui) {
			return;
		}

		Font font = client.font;
		String text = NumberFormat.getIntegerInstance().format(SoulsLogic.souls(client.player));
		int width = font.width(text) + 30;
		int x = graphics.guiWidth() - width - 8;
		int y = graphics.guiHeight() - 30;

		EmberUi.pill(graphics, x, y, width, 16);
		graphics.blitSprite(RenderPipelines.GUI_TEXTURED, SHARD_SPRITE, x + 6, y + 3, 10, 10);
		graphics.drawString(font, text, x + 21, y + 4, EmberUi.GOLD, true);
	}
}
