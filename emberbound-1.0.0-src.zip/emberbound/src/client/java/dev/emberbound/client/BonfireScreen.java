package dev.emberbound.client;

import java.util.List;

import dev.emberbound.BonfireRef;
import dev.emberbound.ModAttachments;
import dev.emberbound.ModNetwork;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;

import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;

/**
 * Меню костра: прокачка, телепорт между кострами, Бездонный ящик.
 */
public class BonfireScreen extends Screen {
	private enum Mode {
		MENU,
		TRAVEL
	}

	private static final int PANEL_W = 260;
	private static final int PER_PAGE = 5;

	private final BlockPos bonfire;
	private Mode mode = Mode.MENU;
	private int page;

	public BonfireScreen(BlockPos bonfire) {
		super(Component.translatable("screen.emberbound.bonfire"));
		this.bonfire = bonfire;
	}

	@Override
	protected void init() {
		this.build();
	}

	@Override
	public boolean isPauseScreen() {
		return false;
	}

	private List<BonfireRef> known() {
		List<BonfireRef> list = this.minecraft.player.getAttached(ModAttachments.BONFIRES);
		return list == null ? List.of() : list;
	}

	private int panelHeight() {
		return this.mode == Mode.MENU ? 176 : 66 + PER_PAGE * 26 + 46;
	}

	private void build() {
		this.clearWidgets();

		int left = (this.width - PANEL_W) / 2;
		int top = (this.height - this.panelHeight()) / 2;

		if (this.mode == Mode.MENU) {
			this.buildMenu(left, top);
		} else {
			this.buildTravel(left, top);
		}
	}

	private void buildMenu(int left, int top) {
		int x = left + 30;
		int width = PANEL_W - 60;

		this.addRenderableWidget(new EmberButton(x, top + 52, width, 22, Component.translatable("screen.emberbound.menu.level_up"),
				() -> this.minecraft.setScreen(new LevelUpScreen())));

		EmberButton travel = this.addRenderableWidget(new EmberButton(x, top + 80, width, 22, Component.translatable("screen.emberbound.menu.travel"), () -> {
			this.mode = Mode.TRAVEL;
			this.page = 0;
			this.build();
		}));
		travel.active = this.known().size() > 1;

		this.addRenderableWidget(new EmberButton(x, top + 108, width, 22, Component.translatable("screen.emberbound.menu.box"), () -> {
			ClientPlayNetworking.send(new ModNetwork.BonfireActionPayload(ModNetwork.BonfireActionPayload.OPEN_BOTTOMLESS_BOX));
		}));

		this.addRenderableWidget(new EmberButton(x, top + 136, width, 22, Component.translatable("screen.emberbound.menu.leave"), this::onClose));
	}

	private void buildTravel(int left, int top) {
		List<BonfireRef> list = this.known();
		int pages = Math.max(1, (list.size() + PER_PAGE - 1) / PER_PAGE);
		this.page = Math.min(this.page, pages - 1);

		int from = this.page * PER_PAGE;
		int to = Math.min(list.size(), from + PER_PAGE);

		for (int i = from; i < to; i++) {
			final int index = i;
			BonfireRef ref = list.get(i);
			boolean here = ref.pos().equals(this.bonfire) && ref.dimension() == this.minecraft.level.dimension();

			Component label = Component.literal("#" + (i + 1) + "  ")
					.append(dimensionName(ref))
					.append(Component.literal("  " + ref.pos().getX() + ", " + ref.pos().getY() + ", " + ref.pos().getZ()));

			if (here) {
				label = label.copy().append(Component.translatable("screen.emberbound.travel.here"));
			}

			EmberButton button = this.addRenderableWidget(new EmberButton(left + 20, top + 58 + (i - from) * 26, PANEL_W - 40, 22, label, () -> {
				ClientPlayNetworking.send(new ModNetwork.TravelPayload(index));
				this.onClose();
			}));
			button.active = !here;
		}

		int bottom = top + this.panelHeight() - 34;

		EmberButton previous = this.addRenderableWidget(new EmberButton(left + 20, bottom, 40, 20, Component.literal("<"), () -> {
			this.page--;
			this.build();
		}));
		previous.active = this.page > 0;

		this.addRenderableWidget(new EmberButton(left + 70, bottom, PANEL_W - 140, 20, Component.translatable("screen.emberbound.back"), () -> {
			this.mode = Mode.MENU;
			this.build();
		}));

		EmberButton next = this.addRenderableWidget(new EmberButton(left + PANEL_W - 60, bottom, 40, 20, Component.literal(">"), () -> {
			this.page++;
			this.build();
		}));
		next.active = this.page < pages - 1;
	}

	private static Component dimensionName(BonfireRef ref) {
		String id = ref.dimension().identifier().toString();

		return switch (id) {
			case "minecraft:overworld" -> Component.translatable("dimension.emberbound.overworld");
			case "minecraft:the_nether" -> Component.translatable("dimension.emberbound.the_nether");
			case "minecraft:the_end" -> Component.translatable("dimension.emberbound.the_end");
			default -> Component.literal(ref.dimension().identifier().getPath());
		};
	}

	@Override
	public void render(GuiGraphics graphics, int mouseX, int mouseY, float delta) {
		this.renderBackground(graphics, mouseX, mouseY, delta);

		int left = (this.width - PANEL_W) / 2;
		int top = (this.height - this.panelHeight()) / 2;
		int centerX = left + PANEL_W / 2;

		EmberUi.panel(graphics, left, top, PANEL_W, this.panelHeight());

		Component heading = this.mode == Mode.MENU ? this.title : Component.translatable("screen.emberbound.menu.travel");
		EmberUi.title(graphics, this.font, heading, centerX, top + 13);
		EmberUi.divider(graphics, left + 16, left + PANEL_W - 16, top + 36);

		if (this.mode == Mode.TRAVEL) {
			int pages = Math.max(1, (this.known().size() + PER_PAGE - 1) / PER_PAGE);
			Component pageText = Component.translatable("screen.emberbound.travel.page", this.page + 1, pages);
			graphics.drawCenteredString(this.font, pageText, centerX, top + 42, EmberUi.MUTED);
		}

		super.render(graphics, mouseX, mouseY, delta);
	}
}
