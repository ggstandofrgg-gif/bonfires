package dev.emberbound.client;

import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.network.chat.Component;

/**
 * Палитра и примитивы интерфейса. Всё рисуется обычными fill/drawString, без своих шейдеров и миксинов,
 * поэтому интерфейс одинаково работает с Sodium и другими рендер-модами.
 */
public final class EmberUi {
	private EmberUi() {
	}

	public static final int PANEL = 0xF01B1215;
	public static final int PANEL_INNER = 0xF0140E11;
	public static final int EDGE = 0xFF4A2A1A;
	public static final int EMBER = 0xFFFF8A2B;
	public static final int EMBER_DIM = 0xFFB4561C;
	public static final int GOLD = 0xFFF2C14E;
	public static final int TEXT = 0xFFEADCCB;
	public static final int MUTED = 0xFF8F7D70;
	public static final int RED = 0xFFE0614D;
	public static final int DISABLED = 0xFF4A3E38;
	public static final int BAR_EMPTY = 0xFF2B1F1C;

	/** Основная панель: тёмное тело, угольная рамка и тлеющие уголки. */
	public static void panel(GuiGraphics graphics, int x, int y, int width, int height) {
		graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xFF0A0506);
		graphics.fill(x, y, x + width, y + height, EDGE);
		graphics.fill(x + 1, y + 1, x + width - 1, y + height - 1, PANEL);
		graphics.fill(x + 4, y + 4, x + width - 4, y + height - 4, PANEL_INNER);

		// Тонкая тлеющая линия внутри панели.
		graphics.fill(x + 4, y + 4, x + width - 4, y + 5, EMBER_DIM);
		graphics.fill(x + 4, y + height - 5, x + width - 4, y + height - 4, EMBER_DIM);

		// Уголки.
		corner(graphics, x + 1, y + 1);
		corner(graphics, x + width - 5, y + 1);
		corner(graphics, x + 1, y + height - 5);
		corner(graphics, x + width - 5, y + height - 5);
	}

	private static void corner(GuiGraphics graphics, int x, int y) {
		graphics.fill(x, y, x + 4, y + 4, EMBER);
		graphics.fill(x + 1, y + 1, x + 3, y + 3, 0xFF1B1215);
	}

	/** Компактная плашка для HUD. */
	public static void pill(GuiGraphics graphics, int x, int y, int width, int height) {
		graphics.fill(x - 1, y - 1, x + width + 1, y + height + 1, 0xCC0A0506);
		graphics.fill(x, y, x + width, y + height, 0xCC1B1215);
		graphics.fill(x, y + height - 1, x + width, y + height, EMBER_DIM);
		graphics.fill(x, y, x + 2, y + height, EMBER);
	}

	/** Ромб из горизонтальных полос. */
	public static void diamond(GuiGraphics graphics, int centerX, int centerY, int radius, int color) {
		for (int i = -radius; i <= radius; i++) {
			int half = radius - Math.abs(i);
			graphics.fill(centerX - half, centerY + i, centerX + half + 1, centerY + i + 1, color);
		}
	}

	/** Разделитель с ромбом посередине. */
	public static void divider(GuiGraphics graphics, int x1, int x2, int y) {
		int mid = (x1 + x2) / 2;
		graphics.fill(x1, y, mid - 8, y + 1, EMBER_DIM);
		graphics.fill(mid + 8, y, x2, y + 1, EMBER_DIM);
		diamond(graphics, mid, y, 3, EMBER);
	}

	/** Крупный заголовок по центру. */
	public static void title(GuiGraphics graphics, Font font, Component text, int centerX, int y) {
		graphics.pose().pushMatrix();
		graphics.pose().translate((float) centerX, (float) y);
		graphics.pose().scale(1.5F);
		graphics.drawCenteredString(font, text, 0, 0, GOLD);
		graphics.pose().popMatrix();
	}
}
