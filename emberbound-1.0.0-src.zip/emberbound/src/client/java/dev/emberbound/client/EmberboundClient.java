package dev.emberbound.client;

import com.mojang.blaze3d.platform.InputConstants;
import dev.emberbound.Emberbound;
import dev.emberbound.ModBlocks;
import dev.emberbound.ModNetwork;
import dev.emberbound.SoulShardItem;
import org.lwjgl.glfw.GLFW;

import net.minecraft.ChatFormatting;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.network.chat.Component;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.item.v1.ItemTooltipCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.hud.VanillaHudElements;

public class EmberboundClient implements ClientModInitializer {
	private static KeyMapping levelUpKey;

	@Override
	public void onInitializeClient() {
		// Пламя костра полупрозрачное, поэтому нужен слой cutout.
		BlockRenderLayerMap.putBlock(ModBlocks.BONFIRE, ChunkSectionLayer.CUTOUT);

		// Клавиша K открывает экран статов (тратить души можно только у костра).
		KeyMapping.Category category = KeyMapping.Category.register(Emberbound.id("main"));
		levelUpKey = KeyBindingHelper.registerKeyBinding(new KeyMapping("key.emberbound.level_up", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_K, category));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (levelUpKey.consumeClick()) {
				if (client.player != null && client.screen == null) {
					client.setScreen(new LevelUpScreen());
				}
			}
		});

		// Счётчик душ.
		HudElementRegistry.attachElementAfter(VanillaHudElements.INFO_BAR, Emberbound.id("souls_counter"), SoulsHud::render);

		// Меню костра открывается по пакету от сервера.
		ClientPlayNetworking.registerGlobalReceiver(ModNetwork.OpenBonfirePayload.TYPE, (payload, context) ->
				context.client().execute(() -> context.client().setScreen(new BonfireScreen(payload.pos()))));

		// Подсказка на кристаллах душ.
		ItemTooltipCallback.EVENT.register((stack, context, type, lines) -> {
			if (stack.getItem() instanceof SoulShardItem shard) {
				lines.add(Component.translatable("tooltip.emberbound.shard_value", shard.tier().souls).withStyle(ChatFormatting.GOLD));
				lines.add(Component.translatable("tooltip.emberbound.shard_use").withStyle(ChatFormatting.GRAY));
			}
		});
	}
}
