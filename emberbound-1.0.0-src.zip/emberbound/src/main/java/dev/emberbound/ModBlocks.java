package dev.emberbound;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;

public final class ModBlocks {
	private ModBlocks() {
	}

	public static final ResourceKey<Block> BONFIRE_KEY = ResourceKey.create(Registries.BLOCK, Emberbound.id("bonfire"));

	public static final BonfireBlock BONFIRE = new BonfireBlock(BlockBehaviour.Properties.of()
			.setId(BONFIRE_KEY)
			.mapColor(MapColor.STONE)
			.strength(3.5F)
			.sound(SoundType.STONE)
			.requiresCorrectToolForDrops()
			.noOcclusion()
			.lightLevel(state -> state.getValue(BonfireBlock.LIT) ? 15 : 0));

	public static void register() {
		Registry.register(BuiltInRegistries.BLOCK, Emberbound.id("bonfire"), BONFIRE);
	}
}
