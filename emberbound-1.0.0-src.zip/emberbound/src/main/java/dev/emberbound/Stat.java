package dev.emberbound;

import net.minecraft.core.Holder;
import net.minecraft.resources.Identifier;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;

/**
 * Пять статов персонажа. Каждое очко даёт постоянный модификатор атрибута.
 */
public enum Stat {
	VIGOR("vigor", Attributes.MAX_HEALTH, AttributeModifier.Operation.ADD_VALUE, 1.0, false),
	STRENGTH("strength", Attributes.ATTACK_DAMAGE, AttributeModifier.Operation.ADD_VALUE, 0.25, false),
	DEXTERITY("dexterity", Attributes.ATTACK_SPEED, AttributeModifier.Operation.ADD_MULTIPLIED_BASE, 0.03, true),
	ENDURANCE("endurance", Attributes.ARMOR, AttributeModifier.Operation.ADD_VALUE, 0.5, false),
	AGILITY("agility", Attributes.MOVEMENT_SPEED, AttributeModifier.Operation.ADD_MULTIPLIED_BASE, 0.01, true);

	public static final Stat[] ALL = values();

	public final String key;
	/** true: бонус показывается в процентах. */
	public final boolean percent;
	private final Holder<Attribute> attribute;
	private final AttributeModifier.Operation operation;
	private final double perLevel;

	Stat(String key, Holder<Attribute> attribute, AttributeModifier.Operation operation, double perLevel, boolean percent) {
		this.key = key;
		this.attribute = attribute;
		this.operation = operation;
		this.perLevel = perLevel;
		this.percent = percent;
	}

	public Identifier modifierId() {
		return Emberbound.id("stat_" + this.key);
	}

	/** Бонус для отображения: в единицах атрибута или в процентах. */
	public double bonus(int level) {
		double value = this.perLevel * level;
		return this.percent ? value * 100.0 : value;
	}

	/** Накладывает (или снимает при уровне 0) постоянный модификатор на игрока. */
	public void apply(ServerPlayer player, int level) {
		AttributeInstance instance = player.getAttribute(this.attribute);

		if (instance == null) {
			return;
		}

		if (level <= 0) {
			instance.removeModifier(this.modifierId());
		} else {
			instance.addOrReplacePermanentModifier(new AttributeModifier(this.modifierId(), this.perLevel * level, this.operation));
		}
	}
}
