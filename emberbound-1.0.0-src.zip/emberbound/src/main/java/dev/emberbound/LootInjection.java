package dev.emberbound;

import java.util.Set;

import net.minecraft.world.level.storage.loot.LootPool;
import net.minecraft.world.level.storage.loot.entries.LootItem;
import net.minecraft.world.level.storage.loot.providers.number.UniformGenerator;

import net.fabricmc.fabric.api.loot.v3.LootTableEvents;

/**
 * Добавляет кристаллы душ в сундуки подземелий, шахт, храмов, кораблекрушений и т.п.
 * Если эта часть мешает сборке, класс можно удалить вместе со строкой в Emberbound.onInitialize.
 */
public final class LootInjection {
	private LootInjection() {
	}

	private static final Set<String> TARGETS = Set.of(
			"minecraft:chests/simple_dungeon",
			"minecraft:chests/abandoned_mineshaft",
			"minecraft:chests/desert_pyramid",
			"minecraft:chests/jungle_temple",
			"minecraft:chests/pillager_outpost",
			"minecraft:chests/shipwreck_treasure",
			"minecraft:chests/buried_treasure",
			"minecraft:chests/ruined_portal",
			"minecraft:chests/igloo_chest",
			"minecraft:chests/underwater_ruin_big",
			"minecraft:chests/stronghold_corridor",
			"minecraft:chests/nether_bridge",
			"minecraft:chests/bastion_treasure",
			"minecraft:chests/end_city_treasure"
	);

	public static void register() {
		LootTableEvents.MODIFY.register((key, tableBuilder, source, registries) -> {
			if (!source.isBuiltin() || !TARGETS.contains(key.identifier().toString())) {
				return;
			}

			LootPool.Builder pool = LootPool.lootPool().setRolls(UniformGenerator.between(0.0F, 2.0F));

			for (SoulTier tier : SoulTier.values()) {
				pool.add(LootItem.lootTableItem(ModItems.SHARDS.get(tier)).setWeight(tier.lootWeight));
			}

			tableBuilder.withPool(pool);
		});
	}
}
