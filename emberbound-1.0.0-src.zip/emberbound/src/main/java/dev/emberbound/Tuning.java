package dev.emberbound;

/**
 * Все числа баланса в одном месте. Меняй и пересобирай.
 */
public final class Tuning {
	private Tuning() {
	}

	/** Максимальный уровень одного стата. */
	public static final int MAX_STAT_LEVEL = 30;

	/** Сколько душ даёт моб за каждую единицу максимального здоровья. */
	public static final double SOULS_PER_MAX_HEALTH = 3.0;

	/** Множитель душ для мирных существ (не монстров). */
	public static final double NON_HOSTILE_FACTOR = 0.25;

	/** Множитель душ за боссов (Дракон Края и Иссушитель). */
	public static final int BOSS_MULTIPLIER = 10;

	/** Терять ли души при смерти (их можно вернуть, дойдя до места гибели). */
	public static final boolean DROP_SOULS_ON_DEATH = true;

	/** Разрешить прокачку в любом месте, а не только рядом с зажжённым костром. */
	public static final boolean LEVEL_UP_ANYWHERE = false;

	/** Радиус в блоках, в котором игрок считается находящимся «у костра». */
	public static final int BONFIRE_REACH = 6;

	/** Радиус проверки врагов, которые мешают отдохнуть у костра. */
	public static final int ENEMY_CHECK_RADIUS = 10;
}
