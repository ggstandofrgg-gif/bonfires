package dev.emberbound;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.exceptions.CommandSyntaxException;

import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

/**
 * Команды для операторов: /souls add|set|reset.
 */
public final class SoulsCommand {
	private SoulsCommand() {
	}

	public static void register() {
		CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> dispatcher.register(
				Commands.literal("souls")
						.requires(Commands.hasPermission(Commands.LEVEL_GAMEMASTERS))
						.then(Commands.literal("add")
								.then(Commands.argument("amount", IntegerArgumentType.integer(0))
										.executes(context -> add(context.getSource(), IntegerArgumentType.getInteger(context, "amount")))))
						.then(Commands.literal("set")
								.then(Commands.argument("amount", IntegerArgumentType.integer(0))
										.executes(context -> set(context.getSource(), IntegerArgumentType.getInteger(context, "amount")))))
						.then(Commands.literal("reset")
								.executes(context -> reset(context.getSource())))
		));
	}

	private static int add(CommandSourceStack source, int amount) throws CommandSyntaxException {
		ServerPlayer player = source.getPlayerOrException();
		SoulsLogic.addSouls(player, amount);
		source.sendSuccess(() -> Component.translatable("command.emberbound.added", amount), false);
		return amount;
	}

	private static int set(CommandSourceStack source, int amount) throws CommandSyntaxException {
		ServerPlayer player = source.getPlayerOrException();
		player.setAttached(ModAttachments.SOULS, amount);
		source.sendSuccess(() -> Component.translatable("command.emberbound.set", amount), false);
		return amount;
	}

	private static int reset(CommandSourceStack source) throws CommandSyntaxException {
		ServerPlayer player = source.getPlayerOrException();
		SoulsLogic.reset(player);
		source.sendSuccess(() -> Component.translatable("command.emberbound.reset"), false);
		return 1;
	}
}
