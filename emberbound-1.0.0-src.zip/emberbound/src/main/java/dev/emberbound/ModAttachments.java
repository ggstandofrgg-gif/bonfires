package dev.emberbound;

import java.util.List;

import com.mojang.serialization.Codec;

import net.minecraft.network.codec.ByteBufCodecs;

import net.fabricmc.fabric.api.attachment.v1.AttachmentRegistry;
import net.fabricmc.fabric.api.attachment.v1.AttachmentSyncPredicate;
import net.fabricmc.fabric.api.attachment.v1.AttachmentType;

/**
 * Данные игрока. Хранятся в сохранении мира, переживают смерть и синхронизируются с самим игроком,
 * поэтому клиент читает их напрямую без собственных пакетов.
 */
public final class ModAttachments {
	private ModAttachments() {
	}

	/** Количество душ в кошельке. */
	public static final AttachmentType<Integer> SOULS = AttachmentRegistry.create(
			Emberbound.id("souls"),
			builder -> builder
					.persistent(Codec.INT)
					.copyOnDeath()
					.syncWith(ByteBufCodecs.VAR_INT, AttachmentSyncPredicate.targetOnly())
	);

	/** Уровни статов в порядке {@link Stat#ALL}. */
	public static final AttachmentType<List<Integer>> STATS = AttachmentRegistry.create(
			Emberbound.id("stats"),
			builder -> builder
					.persistent(Codec.INT.listOf())
					.copyOnDeath()
					.syncWith(ByteBufCodecs.VAR_INT.apply(ByteBufCodecs.list()), AttachmentSyncPredicate.targetOnly())
	);

	/** Костры, которые игрок разжёг или «запомнил». */
	public static final AttachmentType<List<BonfireRef>> BONFIRES = AttachmentRegistry.create(
			Emberbound.id("bonfires"),
			builder -> builder
					.persistent(BonfireRef.CODEC.listOf())
					.copyOnDeath()
					.syncWith(BonfireRef.STREAM_CODEC.apply(ByteBufCodecs.list()), AttachmentSyncPredicate.targetOnly())
	);

	/** Костёр, у которого игрок возрождается. */
	public static final AttachmentType<BonfireRef> LAST_BONFIRE = AttachmentRegistry.create(
			Emberbound.id("last_bonfire"),
			builder -> builder
					.persistent(BonfireRef.CODEC)
					.copyOnDeath()
	);

	/** Потерянные при смерти души. */
	public static final AttachmentType<LostSouls> LOST_SOULS = AttachmentRegistry.create(
			Emberbound.id("lost_souls"),
			builder -> builder
					.persistent(LostSouls.CODEC)
					.copyOnDeath()
	);

	/** Вызов нужен, чтобы класс загрузился и вложения зарегистрировались при старте. */
	public static void register() {
	}
}
