package dev.emberbound;

import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class SoulShardItem extends Item {
	private final SoulTier tier;

	public SoulShardItem(Properties properties, SoulTier tier) {
		super(properties);
		this.tier = tier;
	}

	public SoulTier tier() {
		return this.tier;
	}

	@Override
	public InteractionResult use(Level level, Player player, InteractionHand hand) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}

		if (player instanceof ServerPlayer serverPlayer) {
			ItemStack stack = player.getItemInHand(hand);
			int count = player.isShiftKeyDown() ? stack.getCount() : 1;
			long total = (long) this.tier.souls * count;

			SoulsLogic.addSouls(serverPlayer, (int) Math.min(total, Integer.MAX_VALUE));
			stack.shrink(count);
			level.playSound(null, player.blockPosition(), SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0F, 0.8F);
		}

		return InteractionResult.CONSUME;
	}
}
