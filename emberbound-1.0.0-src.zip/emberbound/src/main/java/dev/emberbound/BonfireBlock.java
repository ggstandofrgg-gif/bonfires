package dev.emberbound;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.RandomSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.Shapes;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * Костёр: каменный алтарь с кучей брёвен. Правый клик разжигает, запоминает его для игрока
 * и открывает меню (прокачка, телепорт, Бездонный ящик).
 */
public class BonfireBlock extends Block {
	public static final BooleanProperty LIT = BlockStateProperties.LIT;

	private static final VoxelShape SHAPE = Shapes.or(
			box(0, 0, 0, 16, 4, 16),
			box(3, 4, 3, 13, 7, 13),
			box(0, 4, 0, 3, 10, 3),
			box(13, 4, 0, 16, 10, 3),
			box(0, 4, 13, 3, 10, 16),
			box(13, 4, 13, 16, 10, 16));

	public BonfireBlock(Properties properties) {
		super(properties);
		this.registerDefaultState(this.defaultBlockState().setValue(LIT, false));
	}

	@Override
	protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
		builder.add(LIT);
	}

	@Override
	public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext context) {
		return SHAPE;
	}

	@Override
	public InteractionResult useWithoutItem(BlockState state, Level level, BlockPos pos, Player player, BlockHitResult hit) {
		if (level.isClientSide()) {
			return InteractionResult.SUCCESS;
		}

		if (player instanceof ServerPlayer serverPlayer && level instanceof ServerLevel serverLevel) {
			BonfireLogic.interact(serverPlayer, serverLevel, pos, state);
		}

		return InteractionResult.CONSUME;
	}

	@Override
	public void animateTick(BlockState state, Level level, BlockPos pos, RandomSource random) {
		if (!state.getValue(LIT)) {
			return;
		}

		double x = pos.getX() + 0.5;
		double y = pos.getY() + 0.45;
		double z = pos.getZ() + 0.5;

		if (random.nextInt(4) == 0) {
			level.addParticle(ParticleTypes.FLAME, x + (random.nextDouble() - 0.5) * 0.4, y + 0.1, z + (random.nextDouble() - 0.5) * 0.4, 0.0, 0.02, 0.0);
		}

		if (random.nextInt(8) == 0) {
			level.addParticle(ParticleTypes.LAVA, x, y + 0.3, z, 0.0, 0.0, 0.0);
		}

		if (random.nextInt(3) == 0) {
			level.addParticle(ParticleTypes.SMOKE, x, y + 0.9, z, 0.0, 0.04, 0.0);
		}

		if (random.nextInt(24) == 0) {
			level.playLocalSound(x, y, z, SoundEvents.CAMPFIRE_CRACKLE, SoundSource.BLOCKS, 0.6F, 0.9F + random.nextFloat() * 0.2F, false);
		}
	}

	/** Есть ли в радиусе от точки зажжённый костёр. Работает и на клиенте, и на сервере. */
	public static boolean isNearLitBonfire(Level level, BlockPos center, int radius) {
		BlockPos min = center.offset(-radius, -radius, -radius);
		BlockPos max = center.offset(radius, radius, radius);

		for (BlockPos checked : BlockPos.betweenClosed(min, max)) {
			BlockState state = level.getBlockState(checked);

			if (state.getBlock() instanceof BonfireBlock && state.getValue(LIT)) {
				return true;
			}
		}

		return false;
	}
}
