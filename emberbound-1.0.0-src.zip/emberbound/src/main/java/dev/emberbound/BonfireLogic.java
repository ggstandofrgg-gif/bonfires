package dev.emberbound;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetTitlesAnimationPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.Mob;
import net.minecraft.world.inventory.ChestMenu;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.portal.TeleportTransition;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/**
 * Серверная логика костров: разжигание, отдых, телепорт и Бездонный ящик.
 */
public final class BonfireLogic {
	private BonfireLogic() {
	}

	public static List<BonfireRef> known(ServerPlayer player) {
		List<BonfireRef> list = player.getAttached(ModAttachments.BONFIRES);
		return list == null ? List.of() : list;
	}

	/** Запоминает костёр для игрока и делает его точкой возрождения. Возвращает true, если костёр новый. */
	private static boolean discover(ServerPlayer player, ServerLevel level, BlockPos pos) {
		BonfireRef ref = new BonfireRef(level.dimension(), pos.immutable());
		List<BonfireRef> list = new ArrayList<>(known(player));
		boolean isNew = !list.contains(ref);

		if (isNew) {
			list.add(ref);
			player.setAttached(ModAttachments.BONFIRES, List.copyOf(list));
		}

		player.setAttached(ModAttachments.LAST_BONFIRE, ref);
		return isNew;
	}

	/** Правый клик по костру. */
	public static void interact(ServerPlayer player, ServerLevel level, BlockPos pos, BlockState state) {
		boolean enemiesNearby = !level.getEntitiesOfClass(
				Mob.class,
				new AABB(pos).inflate(Tuning.ENEMY_CHECK_RADIUS),
				mob -> mob.getTarget() == player
		).isEmpty();

		if (enemiesNearby) {
			player.displayClientMessage(Component.translatable("message.emberbound.enemies_nearby"), true);
			return;
		}

		boolean announce;

		if (!state.getValue(BonfireBlock.LIT)) {
			level.setBlock(pos, state.setValue(BonfireBlock.LIT, true), Block.UPDATE_ALL);
			level.playSound(null, pos, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 1.0F, 1.2F);
			discover(player, level, pos);
			announce = true;
		} else {
			announce = discover(player, level, pos);
		}

		if (announce) {
			player.connection.send(new ClientboundSetTitlesAnimationPacket(10, 50, 20));
			player.connection.send(new ClientboundSetTitleTextPacket(
					Component.translatable("banner.emberbound.bonfire_lit").withStyle(ChatFormatting.GOLD)));
		}

		rest(player, level, pos);
		ServerPlayNetworking.send(player, new ModNetwork.OpenBonfirePayload(pos));
	}

	/** Отдых: полное здоровье и сытость. */
	private static void rest(ServerPlayer player, ServerLevel level, BlockPos pos) {
		player.setHealth(player.getMaxHealth());
		player.getFoodData().setFoodLevel(20);
		player.getFoodData().setSaturation(5.0F);
		level.sendParticles(ParticleTypes.FLAME, pos.getX() + 0.5, pos.getY() + 1.0, pos.getZ() + 0.5, 12, 0.3, 0.4, 0.3, 0.02);
	}

	/** Телепорт к костру из списка игрока. Требует стоять у зажжённого костра. */
	public static void travel(ServerPlayer player, int index) {
		ServerLevel from = (ServerLevel) player.level();

		if (!BonfireBlock.isNearLitBonfire(from, player.blockPosition(), Tuning.BONFIRE_REACH)) {
			player.displayClientMessage(Component.translatable("message.emberbound.too_far"), true);
			return;
		}

		List<BonfireRef> list = known(player);

		if (index < 0 || index >= list.size()) {
			return;
		}

		BonfireRef ref = list.get(index);

		if (!teleportTo(player, ref, false)) {
			return;
		}

		ServerLevel to = (ServerLevel) player.level();
		to.playSound(null, player.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1.0F, 0.7F);
	}

	/**
	 * Переносит игрока к костру. Если костра больше нет, убирает его из списка игрока.
	 *
	 * @param silent не показывать сообщения (для возрождения)
	 */
	public static boolean teleportTo(ServerPlayer player, BonfireRef ref, boolean silent) {
		MinecraftServer server = ((ServerLevel) player.level()).getServer();
		ServerLevel target = server.getLevel(ref.dimension());

		if (target == null) {
			return false;
		}

		BlockState state = target.getBlockState(ref.pos());

		if (!(state.getBlock() instanceof BonfireBlock) || !state.getValue(BonfireBlock.LIT)) {
			List<BonfireRef> list = new ArrayList<>(known(player));
			list.remove(ref);
			player.setAttached(ModAttachments.BONFIRES, List.copyOf(list));

			if (!silent) {
				player.displayClientMessage(Component.translatable("message.emberbound.bonfire_gone"), true);
			}

			return false;
		}

		Vec3 stand = findStandingSpot(target, ref.pos());

		if (stand == null) {
			if (!silent) {
				player.displayClientMessage(Component.translatable("message.emberbound.bonfire_blocked"), true);
			}

			return false;
		}

		player.teleport(new TeleportTransition(target, stand, Vec3.ZERO, player.getYRot(), player.getXRot(), TeleportTransition.DO_NOTHING));
		return true;
	}

	/** Свободное место рядом с костром: воздух на уровне ног и головы, под ногами твёрдая опора. */
	private static Vec3 findStandingSpot(ServerLevel level, BlockPos bonfire) {
		for (int radius = 1; radius <= 2; radius++) {
			for (int dy = 0; dy <= 1; dy++) {
				for (int dx = -radius; dx <= radius; dx++) {
					for (int dz = -radius; dz <= radius; dz++) {
						if (Math.max(Math.abs(dx), Math.abs(dz)) != radius) {
							continue;
						}

						BlockPos feet = bonfire.offset(dx, dy, dz);

						if (level.getBlockState(feet).isAir()
								&& level.getBlockState(feet.above()).isAir()
								&& !level.getBlockState(feet.below()).isAir()
								&& level.getFluidState(feet).isEmpty()) {
							return Vec3.atBottomCenterOf(feet);
						}
					}
				}
			}
		}

		return null;
	}

	/** Бездонный ящик: Сундук Края, доступный у костра. */
	public static void openBottomlessBox(ServerPlayer player) {
		if (!BonfireBlock.isNearLitBonfire(player.level(), player.blockPosition(), Tuning.BONFIRE_REACH)) {
			player.displayClientMessage(Component.translatable("message.emberbound.too_far"), true);
			return;
		}

		player.openMenu(new SimpleMenuProvider(
				(containerId, inventory, ignored) -> ChestMenu.threeRows(containerId, inventory, player.getEnderChestInventory()),
				Component.translatable("container.emberbound.bottomless_box")
		));
	}
}
