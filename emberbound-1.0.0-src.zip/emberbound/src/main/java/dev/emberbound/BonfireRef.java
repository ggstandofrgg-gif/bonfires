package dev.emberbound;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import io.netty.buffer.ByteBuf;

import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** Ссылка на костёр: измерение и позиция. */
public record BonfireRef(ResourceKey<Level> dimension, BlockPos pos) {
	public static final Codec<BonfireRef> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Level.RESOURCE_KEY_CODEC.fieldOf("dimension").forGetter(BonfireRef::dimension),
			BlockPos.CODEC.fieldOf("pos").forGetter(BonfireRef::pos)
	).apply(instance, BonfireRef::new));

	public static final StreamCodec<ByteBuf, BonfireRef> STREAM_CODEC = StreamCodec.composite(
			ResourceKey.streamCodec(Registries.DIMENSION), BonfireRef::dimension,
			BlockPos.STREAM_CODEC, BonfireRef::pos,
			BonfireRef::new
	);
}
