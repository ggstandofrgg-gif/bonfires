package dev.emberbound;

import net.minecraft.resources.Identifier;

import net.fabricmc.api.ModInitializer;

/**
 * Emberbound: костры с телепортом между ними, души с мобов и прокачка статов.
 */
public class Emberbound implements ModInitializer {
	public static final String MOD_ID = "emberbound";

	public static Identifier id(String path) {
		return Identifier.fromNamespaceAndPath(MOD_ID, path);
	}

	@Override
	public void onInitialize() {
		ModBlocks.register();
		ModItems.register();
		ModAttachments.register();
		ModNetwork.register();
		SoulsEvents.register();
		SoulsCommand.register();
		LootInjection.register();
	}
}
