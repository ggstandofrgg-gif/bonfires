package dev.emberbound;

import java.util.ArrayList;
import java.util.List;

import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

/**
 * Игровая логика душ и статов. Всё, что меняет данные, выполняется только на сервере.
 */
public final class SoulsLogic {
	private SoulsLogic() {
	}

	private static final List<Integer> DEFAULT_STATS = List.of(0, 0, 0, 0, 0);

	// --- Чтение данных (работает и на клиенте) ---

	public static int souls(Player player) {
		Integer value = player.getAttached(ModAttachments.SOULS);
		return value == null ? 0 : value;
	}

	public static List<Integer> stats(Player player) {
		List<Integer> value = player.getAttached(ModAttachments.STATS);
		return value == null || value.size() != Stat.ALL.length ? DEFAULT_STATS : value;
	}

	public static int statLevel(Player player, Stat stat) {
		return stats(player).get(stat.ordinal());
	}

	/** Общий уровень персонажа: 1 плюс сумма всех статов. */
	public static int characterLevel(Player player) {
		int level = 1;

		for (int value : stats(player)) {
			level += value;
		}

		return level;
	}

	/** Цена повышения с уровня {@code level} до {@code level + 1}. */
	public static int costOfLevel(int level) {
		return 60 + 24 * level + 4 * level * level;
	}

	/** Цена нескольких повышений подряд, начиная с уровня {@code fromLevel}. */
	public static long costOfPoints(int fromLevel, int points) {
		long total = 0;

		for (int i = 0; i < points; i++) {
			total += costOfLevel(fromLevel + i);
		}

		return total;
	}

	// --- Изменение данных (только сервер) ---

	public static void addSouls(ServerPlayer player, int amount) {
		if (amount <= 0) {
			return;
		}

		long total = (long) souls(player) + amount;
		player.setAttached(ModAttachments.SOULS, (int) Math.min(total, Integer.MAX_VALUE));
		player.displayClientMessage(Component.translatable("message.emberbound.gained", amount), true);
	}

	public static void applyStats(ServerPlayer player) {
		for (Stat stat : Stat.ALL) {
			stat.apply(player, statLevel(player, stat));
		}
	}

	public static void tryLevelUp(ServerPlayer player, int[] add) {
		if (add.length != Stat.ALL.length) {
			return;
		}

		List<Integer> current = stats(player);
		int points = 0;

		for (int i = 0; i < add.length; i++) {
			if (add[i] < 0 || current.get(i) + add[i] > Tuning.MAX_STAT_LEVEL) {
				player.displayClientMessage(Component.translatable("message.emberbound.max_level"), true);
				return;
			}

			points += add[i];
		}

		if (points <= 0 || points > Tuning.MAX_STAT_LEVEL * Stat.ALL.length) {
			return;
		}

		if (!Tuning.LEVEL_UP_ANYWHERE && !BonfireBlock.isNearLitBonfire(player.level(), player.blockPosition(), Tuning.BONFIRE_REACH)) {
			player.displayClientMessage(Component.translatable("message.emberbound.need_bonfire"), true);
			return;
		}

		long cost = costOfPoints(characterLevel(player), points);
		int held = souls(player);

		if (cost > held) {
			player.displayClientMessage(Component.translatable("message.emberbound.not_enough", cost), true);
			return;
		}

		List<Integer> next = new ArrayList<>();

		for (int i = 0; i < add.length; i++) {
			next.add(current.get(i) + add[i]);
		}

		player.setAttached(ModAttachments.STATS, List.copyOf(next));
		player.setAttached(ModAttachments.SOULS, (int) (held - cost));
		applyStats(player);

		if (add[Stat.VIGOR.ordinal()] > 0) {
			player.heal((float) Stat.VIGOR.bonus(add[Stat.VIGOR.ordinal()]));
		}

		player.displayClientMessage(Component.translatable("message.emberbound.leveled_up", characterLevel(player)), true);
		player.level().playSound(null, player.blockPosition(), SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8F, 1.0F);
	}

	public static void reset(ServerPlayer player) {
		player.removeAttached(ModAttachments.SOULS);
		player.removeAttached(ModAttachments.STATS);
		player.removeAttached(ModAttachments.LOST_SOULS);
		applyStats(player);
	}

	// --- Души за убийства, потеря и возврат ---

	/** Сколько душ даёт существо. */
	public static int soulValue(LivingEntity victim) {
		double value = victim.getMaxHealth() * Tuning.SOULS_PER_MAX_HEALTH;

		if (victim.getType().getCategory() != MobCategory.MONSTER) {
			value *= Tuning.NON_HOSTILE_FACTOR;
		}

		if (victim.getType() == EntityType.ENDER_DRAGON || victim.getType() == EntityType.WITHER) {
			value *= Tuning.BOSS_MULTIPLIER;
		}

		return Math.max(1, (int) Math.round(value));
	}

	public static void onDeath(LivingEntity entity, DamageSource source) {
		if (entity instanceof ServerPlayer dead) {
			int held = souls(dead);

			if (Tuning.DROP_SOULS_ON_DEATH && held > 0) {
				dead.setAttached(ModAttachments.LOST_SOULS, new LostSouls(dead.level().dimension(), dead.blockPosition(), held));
				dead.setAttached(ModAttachments.SOULS, 0);
			}

			return;
		}

		if (source.getEntity() instanceof ServerPlayer killer && !(entity instanceof Player)) {
			addSouls(killer, soulValue(entity));
		}
	}

	/** Раз в полсекунды: подсвечивает место гибели и возвращает души, если игрок дошёл. */
	public static void tickRecovery(MinecraftServer server) {
		if (server.getTickCount() % 10 != 0) {
			return;
		}

		for (ServerPlayer player : server.getPlayerList().getPlayers()) {
			LostSouls lost = player.getAttached(ModAttachments.LOST_SOULS);

			if (lost == null || !(player.level() instanceof ServerLevel level) || level.dimension() != lost.dimension()) {
				continue;
			}

			Vec3 center = Vec3.atCenterOf(lost.pos());

			if (player.distanceToSqr(center) < 9.0) {
				player.removeAttached(ModAttachments.LOST_SOULS);
				addSouls(player, lost.amount());
				player.displayClientMessage(Component.translatable("message.emberbound.recovered", lost.amount()), true);
				level.playSound(null, player.blockPosition(), SoundEvents.BEACON_POWER_SELECT, SoundSource.PLAYERS, 1.0F, 1.4F);
			} else {
				level.sendParticles(ParticleTypes.FLAME, center.x, center.y + 0.3, center.z, 4, 0.25, 0.4, 0.25, 0.01);
			}
		}
	}
}
