package dev.emberbound;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;

import net.minecraft.core.BlockPos;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.level.Level;

/** Души, потерянные при смерти: где лежат и сколько их. */
public record LostSouls(ResourceKey<Level> dimension, BlockPos pos, int amount) {
	public static final Codec<LostSouls> CODEC = RecordCodecBuilder.create(instance -> instance.group(
			Level.RESOURCE_KEY_CODEC.fieldOf("dimension").forGetter(LostSouls::dimension),
			BlockPos.CODEC.fieldOf("pos").forGetter(LostSouls::pos),
			Codec.INT.fieldOf("amount").forGetter(LostSouls::amount)
	).apply(instance, LostSouls::new));
}
