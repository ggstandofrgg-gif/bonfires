package dev.emberbound;

import net.minecraft.core.BlockPos;
import net.minecraft.network.RegistryFriendlyByteBuf;
import net.minecraft.network.codec.ByteBufCodecs;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.server.level.ServerPlayer;

import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;

/**
 * Пакеты. Состояние игрока (души, статы, список костров) синхронизируется вложениями данных,
 * поэтому пакетов нужно всего четыре.
 */
public final class ModNetwork {
	private ModNetwork() {
	}

	/** Сервер -> клиент: открыть меню костра. */
	public record OpenBonfirePayload(BlockPos pos) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<OpenBonfirePayload> TYPE = new CustomPacketPayload.Type<>(Emberbound.id("open_bonfire"));
		public static final StreamCodec<RegistryFriendlyByteBuf, OpenBonfirePayload> CODEC = StreamCodec.composite(
				BlockPos.STREAM_CODEC, OpenBonfirePayload::pos,
				OpenBonfirePayload::new
		);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Клиент -> сервер: потратить души, добавив очки в статы (порядок как в {@link Stat#ALL}). */
	public record LevelUpPayload(int vigor, int strength, int dexterity, int endurance, int agility) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<LevelUpPayload> TYPE = new CustomPacketPayload.Type<>(Emberbound.id("level_up"));
		public static final StreamCodec<RegistryFriendlyByteBuf, LevelUpPayload> CODEC = StreamCodec.composite(
				ByteBufCodecs.VAR_INT, LevelUpPayload::vigor,
				ByteBufCodecs.VAR_INT, LevelUpPayload::strength,
				ByteBufCodecs.VAR_INT, LevelUpPayload::dexterity,
				ByteBufCodecs.VAR_INT, LevelUpPayload::endurance,
				ByteBufCodecs.VAR_INT, LevelUpPayload::agility,
				LevelUpPayload::new
		);

		public static LevelUpPayload of(int[] points) {
			return new LevelUpPayload(points[0], points[1], points[2], points[3], points[4]);
		}

		public int[] toArray() {
			return new int[] {this.vigor, this.strength, this.dexterity, this.endurance, this.agility};
		}

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Клиент -> сервер: телепорт к костру с номером из списка игрока. */
	public record TravelPayload(int index) implements CustomPacketPayload {
		public static final CustomPacketPayload.Type<TravelPayload> TYPE = new CustomPacketPayload.Type<>(Emberbound.id("travel"));
		public static final StreamCodec<RegistryFriendlyByteBuf, TravelPayload> CODEC = StreamCodec.composite(
				ByteBufCodecs.VAR_INT, TravelPayload::index,
				TravelPayload::new
		);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	/** Клиент -> сервер: действие меню костра. */
	public record BonfireActionPayload(int action) implements CustomPacketPayload {
		public static final int OPEN_BOTTOMLESS_BOX = 0;

		public static final CustomPacketPayload.Type<BonfireActionPayload> TYPE = new CustomPacketPayload.Type<>(Emberbound.id("bonfire_action"));
		public static final StreamCodec<RegistryFriendlyByteBuf, BonfireActionPayload> CODEC = StreamCodec.composite(
				ByteBufCodecs.VAR_INT, BonfireActionPayload::action,
				BonfireActionPayload::new
		);

		@Override
		public CustomPacketPayload.Type<? extends CustomPacketPayload> type() {
			return TYPE;
		}
	}

	public static void register() {
		PayloadTypeRegistry.playS2C().register(OpenBonfirePayload.TYPE, OpenBonfirePayload.CODEC);
		PayloadTypeRegistry.playC2S().register(LevelUpPayload.TYPE, LevelUpPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(TravelPayload.TYPE, TravelPayload.CODEC);
		PayloadTypeRegistry.playC2S().register(BonfireActionPayload.TYPE, BonfireActionPayload.CODEC);

		ServerPlayNetworking.registerGlobalReceiver(LevelUpPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			context.server().execute(() -> SoulsLogic.tryLevelUp(player, payload.toArray()));
		});

		ServerPlayNetworking.registerGlobalReceiver(TravelPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			context.server().execute(() -> BonfireLogic.travel(player, payload.index()));
		});

		ServerPlayNetworking.registerGlobalReceiver(BonfireActionPayload.TYPE, (payload, context) -> {
			ServerPlayer player = context.player();
			context.server().execute(() -> {
				if (payload.action() == BonfireActionPayload.OPEN_BOTTOMLESS_BOX) {
					BonfireLogic.openBottomlessBox(player);
				}
			});
		});
	}
}
