package dev.emberbound;

import net.minecraft.world.item.Rarity;

/**
 * Семь уровней кристаллов душ. Правый клик поглощает кристалл, Shift + правый клик поглощает всю стопку.
 */
public enum SoulTier {
	ASH_FRAGMENT("ash_fragment", 25, Rarity.COMMON, 400),
	CINDER_SHARD("cinder_shard", 100, Rarity.COMMON, 250),
	EMBER_SHARD("ember_shard", 400, Rarity.UNCOMMON, 150),
	BLAZE_SHARD("blaze_shard", 1000, Rarity.UNCOMMON, 90),
	PYRE_SHARD("pyre_shard", 2500, Rarity.RARE, 60),
	INFERNO_SHARD("inferno_shard", 7500, Rarity.EPIC, 40),
	PHOENIX_HEART("phoenix_heart", 25000, Rarity.EPIC, 10);

	public final String id;
	public final int souls;
	public final Rarity rarity;
	/** Вес в таблице лута сундуков. */
	public final int lootWeight;

	SoulTier(String id, int souls, Rarity rarity, int lootWeight) {
		this.id = id;
		this.souls = souls;
		this.rarity = rarity;
		this.lootWeight = lootWeight;
	}
}
