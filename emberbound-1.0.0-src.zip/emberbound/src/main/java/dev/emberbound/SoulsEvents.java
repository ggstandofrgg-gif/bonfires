package dev.emberbound;

import net.minecraft.server.level.ServerPlayer;

import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/**
 * Подписки на события игры: души за убийства, потеря души при смерти, возрождение у костра.
 */
public final class SoulsEvents {
	private SoulsEvents() {
	}

	public static void register() {
		ServerLivingEntityEvents.AFTER_DEATH.register(SoulsLogic::onDeath);

		ServerPlayerEvents.JOIN.register(SoulsLogic::applyStats);

		ServerPlayerEvents.AFTER_RESPAWN.register((oldPlayer, newPlayer, alive) -> {
			if (alive) {
				return;
			}

			SoulsLogic.applyStats(newPlayer);

			BonfireRef last = newPlayer.getAttached(ModAttachments.LAST_BONFIRE);

			if (last != null) {
				BonfireLogic.teleportTo(newPlayer, last, true);
			}

			newPlayer.setHealth(newPlayer.getMaxHealth());
		});

		ServerTickEvents.END_SERVER_TICK.register(SoulsLogic::tickRecovery);
	}
}
