package dev.emberbound;

import java.util.EnumMap;
import java.util.Map;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;

public final class ModItems {
	private ModItems() {
	}

	public static final BlockItem BONFIRE = new BlockItem(ModBlocks.BONFIRE, new Item.Properties().setId(key("bonfire")));

	public static final Map<SoulTier, SoulShardItem> SHARDS = new EnumMap<>(SoulTier.class);

	static {
		for (SoulTier tier : SoulTier.values()) {
			SHARDS.put(tier, new SoulShardItem(new Item.Properties().setId(key(tier.id)).rarity(tier.rarity), tier));
		}
	}

	private static ResourceKey<Item> key(String path) {
		return ResourceKey.create(Registries.ITEM, Emberbound.id(path));
	}

	public static void register() {
		Registry.register(BuiltInRegistries.ITEM, Emberbound.id("bonfire"), BONFIRE);

		for (Map.Entry<SoulTier, SoulShardItem> entry : SHARDS.entrySet()) {
			Registry.register(BuiltInRegistries.ITEM, Emberbound.id(entry.getKey().id), entry.getValue());
		}

		Registry.register(BuiltInRegistries.CREATIVE_MODE_TAB, Emberbound.id("main"), FabricItemGroup.builder()
				.title(Component.translatable("itemGroup.emberbound.main"))
				.icon(() -> new ItemStack(BONFIRE))
				.displayItems((parameters, output) -> {
					output.accept(BONFIRE);

					for (SoulShardItem item : SHARDS.values()) {
						output.accept(item);
					}
				})
				.build());
	}
}
